import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { authguardGuard } from './authguard.guard';
import { ProfileComponent } from './dashboard/profile/profile.component';
import { SettingComponent } from './dashboard/setting/setting.component';
import { FormComponent } from './form/form.component';
import { RegisterationComponent } from './registeration/registeration.component';

const routes: Routes = [
  // {path:'form',component:FormComponent, canDeactivate:[authguardGuard]},
  {path:'form',component:FormComponent, resolve:{user:authguardGuard}},
  {path:'user',loadChildren:()=>import('./user/user.module').then(m=>m.UserModule)},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterationComponent,canDeactivate:[authguardGuard]},
  // {path:'dashboard',component:DashboardComponent,canActivate:[authguardGuard]}
  {path:'dashboard',component:DashboardComponent,canActivate:[authguardGuard], canActivateChild:[authguardGuard], children:[
    {path:'profile',component:ProfileComponent},
  {path:'setting',component:SettingComponent}]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
