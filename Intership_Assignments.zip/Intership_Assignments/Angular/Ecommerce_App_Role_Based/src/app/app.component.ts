import { Component } from '@angular/core';
import { NavigationCancel, Router, Event, ResolveStart, ResolveEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'guardapp';
    constructor(private router:Router){
      this.router.events.subscribe((event: Event) => { 
        if (event instanceof NavigationCancel) {
          console.log("Navigation Cancelled",event);
          // alert("Navigation Cancelled");
        }
        if(event instanceof ResolveStart){
          console.log("Resolve start",event)
        }
        if(event instanceof ResolveEnd){
          console.log("Resolve End",event)
        }
      });
    }
}
