import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GuardService } from '../guardservice.service';

@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  // login(){
  //   localStorage.setItem('loggedIn','true');
  //   this.router.navigate(['/dashboard'])
  // }

  //with service
  // login(){
  //   this.guardservice.login();
  //   this.router.navigate(['/dashboard'])
  // }

  //for role based
  // login(user:string){
  //   if(user=='Admin'){
  //     this.guardservice.login();
  //     this.router.navigate(['/dashboard'])
  //   }
  //   else{
  //     alert("Only Admin can access!")
  //   }
  // }

  login(){
    localStorage.setItem('role','User');
    localStorage.setItem('loggedIn','true');
    this.router.navigate(['/dashboard']);
  }

  adminLogin(){
    localStorage.setItem('role','Admin');
    localStorage.setItem('loggedIn','true');
    this.router.navigate(['/dashboard'])
  }

  constructor(private router:Router, private guardservice:GuardService){}
}

