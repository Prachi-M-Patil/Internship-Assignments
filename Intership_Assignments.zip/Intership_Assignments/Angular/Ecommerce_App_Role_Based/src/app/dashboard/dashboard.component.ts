import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GuardService } from '../guardservice.service';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  logout(){
    localStorage.setItem('loggedIn','false');
    this.router.navigate(['/login']);
  }
  // logout(){
  //   this.guardservice.logout();
  //   this.router.navigate(['/login']);
  // }
  constructor(private router:Router,private guardservice: GuardService){}
}
