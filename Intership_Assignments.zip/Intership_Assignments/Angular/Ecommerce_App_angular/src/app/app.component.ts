import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CartService } from './cart.service';
import { CommonModule } from '@angular/common';
import { ProductItems } from './cart.service';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  
  
  ProductItemss: ProductItems[] = [
    { id: 1, name: 'SmartPhone', price: 10000 },
    { id: 2, name: 'Laptop', price: 50000},
    { id: 3, name: 'Accessories', price: 700 }
  ];

  cartItems: ProductItems[] = [];
  totalPrice: number = 0;

  constructor(private cartService: CartService) {}

  addToCart(ProductItems: ProductItems): void {
    this.cartService.addToCart(ProductItems);
    this.updateCart();
  }

  removeFromCart(ProductItems: ProductItems): void {
    this.cartService.removeFromCart(ProductItems);
    this.updateCart();
  }

  updateCart(): void {
    this.cartItems = this.cartService.getCartItems();
    this.totalPrice = this.cartService.getTotalPrice();
  }


}
