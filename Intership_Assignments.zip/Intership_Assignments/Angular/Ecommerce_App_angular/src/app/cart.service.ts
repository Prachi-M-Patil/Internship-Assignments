import { Injectable } from '@angular/core';

export interface ProductItems{
  id: number;
  name: string;
  price: number;

}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems: ProductItems[] = [];

  addToCart(ProductItems: ProductItems): void{
    this.cartItems.push(ProductItems);
  }

  removeFromCart(ProductItems:ProductItems):void{
    const index = this.cartItems.findIndex((item)=> item.id === ProductItems.id);
    if(index !== -1){
      this.cartItems.splice(index, 1);
    }
  }

  getCartItems(): ProductItems[]
  {
    return this.cartItems;

  }

  getTotalPrice(): number{
    console.log("hii");
    return this.cartItems.reduce((total, item) => total + item.price, 0);
  }
}
