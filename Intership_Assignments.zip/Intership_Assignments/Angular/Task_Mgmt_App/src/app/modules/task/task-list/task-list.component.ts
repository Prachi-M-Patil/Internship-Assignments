import { Component } from '@angular/core';
import { Task } from '../task.model';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task-list',
  standalone: false,
  
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent {
  tasks : Task[];

  constructor(private taskService: TaskService){
    this.tasks = this.taskService.getTasks();
    
  }

  updateTask(id:number, newstatus: 'pending'| 'in progress' | 'completed'){
    this.taskService.updateTask(id, newstatus);
  }

  deleteTask(id: number){
    this.taskService.deleteTask(id);
    this.tasks= this.taskService.getTasks();
  }


}
