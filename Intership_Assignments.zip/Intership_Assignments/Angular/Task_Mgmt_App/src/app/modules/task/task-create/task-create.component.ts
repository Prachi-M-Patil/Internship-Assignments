import { Component } from '@angular/core';
import { Task } from '../task.model';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task-create',
  standalone: false,
  
  templateUrl: './task-create.component.html',
  styleUrl: './task-create.component.css'
})
export class TaskCreateComponent {
  tasks : Task[];

  constructor(private taskService: TaskService){
    this.tasks = this.taskService.getTasks();

  }

  addTask(name : string, priority: 'high'|'low'|'medium'){
    if(name){
      this.taskService.addTask(name, priority);
    }
  }

}
