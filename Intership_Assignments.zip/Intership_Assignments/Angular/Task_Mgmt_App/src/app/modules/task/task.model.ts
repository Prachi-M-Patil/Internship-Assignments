export interface Task{
    id: number;
    name: string;
    status: 'pending'| 'in progress' | 'completed';
    priority: 'low'| 'high'| 'medium';
}