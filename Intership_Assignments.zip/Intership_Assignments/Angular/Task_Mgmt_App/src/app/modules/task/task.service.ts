import { Injectable } from '@angular/core';
import { Task } from './task.model';
@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor() { }

  private tasks : Task[] = [
    {id: 1, name: "approve reports", status: 'pending', priority:'high'},
    {id: 2, name: "make reports", status:'in progress', priority:'high'},
    {id: 3, name: "check reports", status:'in progress', priority:'medium'},

  ];

  getTasks(): Task[]{
    return this.tasks;

  }

  addTask(name: string, priority: 'high'|'low'|'medium'): void{
    const newtask: Task= {
      id: this.tasks.length +1,
      name,
      status: 'pending',
      priority
    };
    this.tasks.push(newtask);
  }

  updateTask(id:number, newstatus: 'pending'| 'in progress' | 'completed'){
    const task = this.tasks.find(t => t.id === id);
    if(task){
      task.status = newstatus;

    }
  }
  deleteTask(id: number): void{
    this.tasks = this.tasks.filter(t=> t.id !== id);
  }

}
