import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CartService, FoodItem } from './cart.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  
  
  foodItems: FoodItem[] = [
    { id: 1, name: 'Pizza', price: 10 },
    { id: 2, name: 'Burger', price: 5 },
    { id: 3, name: 'Pasta', price: 7 }
  ];

  cartItems: FoodItem[] = [];
  totalPrice: number = 0;

  constructor(private cartService: CartService) {}

  addToCart(foodItem: FoodItem): void {
    this.cartService.addToCart(foodItem);
    this.updateCart();
  }

  removeFromCart(foodItem: FoodItem): void {
    this.cartService.removeFromCart(foodItem);
    this.updateCart();
  }

  updateCart(): void {
    this.cartItems = this.cartService.getCartItems();
    this.totalPrice = this.cartService.getTotalPrice();
  }


}
