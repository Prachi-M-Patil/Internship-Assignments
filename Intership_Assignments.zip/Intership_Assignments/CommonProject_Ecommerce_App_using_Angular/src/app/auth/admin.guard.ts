import { CanActivateFn, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

Injectable({
  providedIn: 'root'
})

export class adminGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean {
    let value = localStorage.getItem("isLogged");
    
    if(value!== 'true'){
      return false;
    }

    let role = localStorage.getItem('role');

    if(role == 'Admin'){
      return true;
    }

    this.router.navigate(['/']);
    return false;

  }
  
}