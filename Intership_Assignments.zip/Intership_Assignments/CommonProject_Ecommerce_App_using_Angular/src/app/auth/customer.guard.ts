import { CanActivate, CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot, Router, GuardResult, MaybeAsync } from '@angular/router';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { Role } from '../role';


@Injectable({
  providedIn:"root"
})
export class CustomerGuard implements CanActivate {
  constructor(private authService:AuthService){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.authService.isUserAuthenticated(Role.Customer)
  }
  
  
}