import { Injectable } from '@angular/core';
export interface Order {
  id: number;
  name: string;
  description: string;
  total: number;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private orders: Order[] = [
    { id: 1, name: 'Order 1', description: 'Description 1', total: 100 },
    { id: 2, name: 'Order 2', description: 'Description 2', total: 200 }
  ];

  getOrders(): Order[] {
    return this.orders;
  }

  getOrderById(id: number): Order | undefined {
    return this.orders.find(order => order.id === id);
  }

  deleteOrder(id: number): void {
    this.orders = this.orders.filter(order => order.id !== id);
  }
}
