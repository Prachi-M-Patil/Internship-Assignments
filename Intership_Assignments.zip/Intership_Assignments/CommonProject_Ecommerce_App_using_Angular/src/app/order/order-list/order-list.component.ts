import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { Order } from '../order.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  standalone:false,
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {
  orders: Order[] = [];

  constructor(private router:Router,private orderService: OrderService) { }

  ngOnInit(): void {
    this.orders = this.orderService.getOrders();
  }

  deleteOrder(id: number): void {
    this.orderService.deleteOrder(id);
    this.orders = this.orderService.getOrders(); // Refresh the list
  }
  viewDetails(order: Order){
    this.router.navigate(['/orderdetails', order.id])
  }
}
