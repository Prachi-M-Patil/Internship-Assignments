import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipeDemo',
  standalone: false
})
export class PipeDemoPipe implements PipeTransform {
//join is used to reverse the string

  transform(value: string):string {
    const visible =4;
    const masked = value.slice(0, -visible).replace(/\d/g, "*");
    const visibleSection= value.slice(-visible);

    return `${masked}${visibleSection}`;
  }

}
