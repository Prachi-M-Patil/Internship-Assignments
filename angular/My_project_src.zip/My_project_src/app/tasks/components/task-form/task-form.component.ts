import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TasksService } from '../../../core/services/task.service';

@Component({
  selector: 'app-task-form',
  standalone: false,
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {
  task = { id: null, title: '', description: '', status: 'pending' };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tasksService: TasksService
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.task = this.tasksService.getTaskById(Number(id)) || this.task;
    }
  }

  saveTask() {
    if (this.task.id) {
      this.tasksService.updateTask(this.task.id, this.task);
    } else {
      this.tasksService.addTask(this.task);
    }
    this.router.navigate(['/tasks']);
  }
}
