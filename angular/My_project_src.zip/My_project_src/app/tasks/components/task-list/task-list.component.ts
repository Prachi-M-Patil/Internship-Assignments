import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TasksService } from '../../../core/services/task.service';

@Component({
  selector: 'app-task-list',
  standalone: false,
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  tasks: any[] = [];

  constructor(private tasksService: TasksService, public router: Router) {}

  ngOnInit() {
    this.tasks = this.tasksService.getTasks();
  }

  viewDetails(id: number) {
    this.router.navigate(['/tasks/details', id]);
  }

  editTask(id: number) {
    this.router.navigate(['/tasks/form', id]);
  }

  deleteTask(id: number) {
    this.tasksService.deleteTask(id);
    this.tasks = this.tasksService.getTasks();
  }
}
