import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [CommonModule],
  providers: [], // No need to re-provide services here since they are provided in `root`
})
export class CoreModule {}
