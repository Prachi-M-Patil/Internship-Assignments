import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isLoggedInSubject = new BehaviorSubject<boolean>(this.isAuthenticated());

  constructor(private router: Router) {}

  login(email: string, password: string, role: string) {
    localStorage.setItem('userToken', 'mock-token');
    localStorage.setItem('userRole', role);
    localStorage.setItem('userEmail', email);
    this.isLoggedInSubject.next(true);
    this.router.navigate(['/tasks']);
  }

  logout() {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    this.isLoggedInSubject.next(false);
    this.router.navigate(['/auth/login']);
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('userToken');
  }

  getUserRole(): string | null {
    return localStorage.getItem('userRole');
  }

  getLoginStatus() {
    return this.isLoggedInSubject.asObservable();
  }
}
