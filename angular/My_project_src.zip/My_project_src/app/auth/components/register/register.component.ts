import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  email = '';
  password = '';

  constructor(private router: Router) {}

  register() {
    localStorage.setItem('userEmail', this.email);
    this.router.navigate(['/auth/login']);
  }
}
