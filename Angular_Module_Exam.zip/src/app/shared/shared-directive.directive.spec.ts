import { SharedDirectiveDirective } from './shared-directive.directive';

describe('SharedDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new SharedDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
