import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sharedPipe',
  standalone: false
})
export class SharedPipePipe implements PipeTransform {

  transform(value: string): string {
    return value.toUpperCase();
  }

}
