import { SharedPipePipe } from './shared-pipe.pipe';

describe('SharedPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SharedPipePipe();
    expect(pipe).toBeTruthy();
  });
});
