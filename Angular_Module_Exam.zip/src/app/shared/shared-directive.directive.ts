import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appSharedDirective]',
  standalone: false
})
export class SharedDirectiveDirective {

  
   constructor(private el : ElementRef ) { 
    //el.nativeElement.style.color='red'
  }

  highlight: string= 'yellow';

  @HostListener ('mouseenter') onMouseEnter(){
    this.highlights(this.highlight);
  }

  @HostListener ('mouseleave') onMouseLeave(){
    this.highlights(null);
  }


  private highlights(color: string| null){
    this.el.nativeElement.style.backgroundColor = color;
  }


}
