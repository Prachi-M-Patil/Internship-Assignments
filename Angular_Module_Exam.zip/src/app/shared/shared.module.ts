import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedComponentComponent } from './shared-component/shared-component.component';
import { SharedDirectiveDirective } from './shared-directive.directive';
import { SharedPipePipe } from './shared-pipe.pipe';



@NgModule({
  declarations: [
    SharedComponentComponent,
    SharedDirectiveDirective,
    SharedPipePipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    SharedComponentComponent,
    SharedDirectiveDirective,
    SharedPipePipe
  ]
})
export class SharedModule { }
