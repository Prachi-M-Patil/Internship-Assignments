import { Component } from '@angular/core';

@Component({
  selector: 'app-shared-component',
  standalone: false,
  templateUrl: './shared-component.component.html',
  styleUrl: './shared-component.component.css'
})
export class SharedComponentComponent {

}
