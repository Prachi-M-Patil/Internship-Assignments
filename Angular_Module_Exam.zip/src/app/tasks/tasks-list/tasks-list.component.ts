import { Component } from '@angular/core';

export interface Task{
  id: number,
  name: string,
  status: 'pending'| 'in progress' | 'completed',
  priority: 'high'| 'low'| 'medium'
}
@Component({
  selector: 'app-tasks-list',
  standalone: false,
  templateUrl: './tasks-list.component.html',
  styleUrl: './tasks-list.component.css'
})
export class TasksListComponent {
   tasks: Task[]= [
    {id: 1, name:"abc", status:"pending", priority: "high"},
    {id: 2, name:"xyz", status:"in progress", priority: "low"},
    {id: 3, name:"xyz", status:"in progress", priority: "low"},


  ]
  getTasks(): Task[]{
    return this.tasks;
  }

  


}
