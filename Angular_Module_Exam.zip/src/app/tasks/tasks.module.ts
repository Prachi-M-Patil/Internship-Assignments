import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TasksComponent } from './tasks.component';
import { RegisterComponent } from './register/register.component';
import { SharedModule } from '../shared/shared.module';
import { TasksListComponent } from './tasks-list/tasks-list.component';



@NgModule({
  declarations: [
    TasksComponent,
    RegisterComponent,
    TasksListComponent
  ],
  imports: [
    CommonModule,
    SharedModule
  ],
  exports:[
    TasksListComponent
  ]
 
})
export class TasksModule { }
