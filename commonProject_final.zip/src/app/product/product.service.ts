import { Injectable } from "@angular/core";

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
}


@Injectable({
  providedIn: 'root'
})

export class ProductService {

  private products: Product[] = [
    { id: 1, name: 'Product 1', description: 'Description 1', price: 100, quantity: 2 },
    { id: 2, name: 'Product 2', description: 'Description 2', price: 200, quantity: 1 }
  ];
  private cart: Product[] = [];

  constructor() { }

  getProducts(): Product[] {
    return this.products;
  }

  getProductById(id: number): Product | undefined {
    return this.products.find(p => p.id === id);
  }

  addProduct(product: Product): Product {
    product.id = this.products.length + 1;
    this.products.push(product);
    return product;
  }
  
  deleteProduct(id: number): void {
    this.products = this.products.filter(p => p.id !== id);
  }

  addToCart(product: Product): void {
    this.cart.push(product);
  }

  getCart(): Product[] {
    return this.cart;
  }

  clearCart(): void {
    this.cart = [];
  }



  // updateProduct(id: number, updatedProduct: Product): Product | undefined {
  //   const index = this.products.findIndex(p => p.id === id);
  //   if (index !== -1) {
  //     this.products[index] = updatedProduct;
  //     return updatedProduct;
  //   }
  //   return undefined;
  // }

  
}
