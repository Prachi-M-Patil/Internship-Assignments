import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { RouterModule, Routes } from '@angular/router';
import { ProductService } from './product.service';
import { PipeDemoPipe } from '../pipe-demo.pipe';
import { ProductRoutingModule } from './product-routing.module';

const routes: Routes = [
  { path: '', component: ProductListComponent },
  {path:'product-details', component:ProductDetailsComponent}

];

@NgModule({
  declarations: [
    ProductListComponent,
    ProductDetailsComponent,
    PipeDemoPipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ProductRoutingModule
  ],
  providers: [ProductService, DecimalPipe],
})
export class ProductModule { }
