import { Component } from '@angular/core';
import { Product, ProductService } from '../product.service';
import { Router } from '@angular/router';
import { OrderService } from '../../order/order.service';

@Component({
  selector: 'app-product-list',
  standalone: false,
  
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  // title:string= "my Website";
  // today= new Date();
   products: Product[] = [];
   cart: Product[] = [];

  // cnum = '12345678993456';

  constructor(private router: Router,private productService: ProductService, private orderService: OrderService) {
    this.products = this.productService.getProducts();
    this.cart = this.productService.getCart();

  }

  addProduct(){
    const newProduct: Product = { id: 0, name: 'New Product', description: 'New Description', price: 0 , quantity: 1};
    this.productService.addProduct(newProduct);
    this.products = this.productService.getProducts(); // Refresh the product list
   
  }

  deleteProduct(id: number): void {
    this.productService.deleteProduct(id);
    this.products = this.productService.getProducts(); 
  }

  viewProductDetails(product: Product){
      this.router.navigate(['/productdetails', product.id])
  }

  addToCart(product: Product): void {
      this.productService.addToCart(product);
      this.cart = this.productService.getCart(); // Refresh the cart
  }
  
  orderNow(product: Product): void {
    const newOrder = { id: 0, name: product.name, description: product.description, price: product.price , quantity:1};
    this.orderService.getOrders().push(newOrder);
    this.productService.clearCart();
    this.router.navigate(['/order']);
  }
}
