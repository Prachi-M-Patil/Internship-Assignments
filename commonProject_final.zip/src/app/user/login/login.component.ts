import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Role } from '../../role';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  constructor(private router: Router, private authService: AuthService){ 

  }
  // role: string = 'admin';

   loginForm: FormGroup = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(3)]),
      password: new FormControl('', [Validators.required, Validators.minLength(8)])  
  
    });

    // login(role: Role){
    //   console.log('form submitted', this.loginForm.value);
    //   alert("form submitted");
    //   this.authService.login(role);
    //   this.router.navigate(['/dashboard']);
    // }
    onSubmit(){
      // if(!Role.Admin || !Role.Manager){
        
      // }
     
      // const role = this.authService.getRole();
      let role: Role | null = null;
      const { name, password } = this.loginForm.value;
      if( name==='admin' && password==='admin123456'){
        role = Role.Admin;
      }else if (name === 'manager' && password === 'manager123') {
        role = Role.Manager;
      } else if (name === 'customer' && password === 'customer') {
        role = Role.Customer;
      }

      if (role) {
        this.authService.login(role);
        console.log(`${role} login successful`, this.loginForm.value);
        alert(`${role} login successful`);
        this.router.navigate(['/user/dashboard']);
      } else {
        console.log('Login failed', this.loginForm.value);
        alert("Login failed");
      }



    }

  }









      //   console.log('form submitted', this.loginForm.value);
      //   alert("form submitted");
      //   this.router.navigate(['/user/dashboard']);
      // }
      // else if( name==='manager' && password==='manager'){
      //   console.log('form submitted', this.loginForm.value);
      //   alert("form submitted");
      //   this.router.navigate(['/user/dashboard']);
      // }
      // else if ( name === 'customer' && password === 'manager') {
      //   console.log('Manager login successful', this.loginForm.value);
      //   alert("Manager login successful");
      //   this.router.navigate(['/dashboard']);
      // } else {
      //   console.log('Login failed', this.loginForm.value);
      //   alert("Login failed");
      // }
     
  


