import { Injectable } from '@angular/core';
import { Role } from '../role';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private route:Router){
    
  }

  login(role: Role){
    localStorage.setItem('isLogged', 'true');
    localStorage.setItem('role', JSON.stringify(Role[role]));
    this.route.navigate(['/order'])
  }

  getRole(): Role | null{
    let isLoggedin = localStorage.getItem('isLogged')=== 'true';
    let role =  localStorage.getItem('role');
    if (isLoggedin && role) {
      return role as Role;
    }
    return null;
  }

  isCustomer(): boolean {
    const role = this.getRole();
    if (!role) {
      alert("Login first!");
      this.route.navigate(['user/login']);
      return false;
    }
    if (role === Role.Manager) {
      alert("You don't have access");
      return false;
    }
    return true;
  }

  isManager(): boolean {
    const role = this.getRole();
    if (!role) {
      alert("Login first!");
      this.route.navigate(['user/login']);
      return false;
    }
    if (role === Role.Customer) {
      alert("You don't have access");
      return false;
    }
    return true;
  }

  isAdmin(): boolean {
    const role = this.getRole();
    if (!role) {
      alert("Login first!");
      this.route.navigate(['user/login']);
      return false;
    }
    if (role !== Role.Admin) {
      alert("You don't have access");
      return false;
    }
    return true;
  }
}


  // constructor(private route: Router) {

  //  }
  //  userLogIn(){
  //   localStorage.setItem('isLoggedIn', 'true');
  //   localStorage.setItem('role', Role.Customer);
  //   this.route.navigate(['/']);
  //  }

//    isUserAuthenticated(role:Role){
//     const isLoggedIn = localStorage.getItem('isLogged') === 'true';
//     console.log(isLoggedIn)
//     if(!isLoggedIn){
//       alert("Login first");
//       this.route.navigate(['/login']);
//       return false; 
//     }
//     if(role===Role.Customer){
//     return true;
//    }else{
//     alert(`You have not access`);
//     return false;
//    }
//   }
// }
