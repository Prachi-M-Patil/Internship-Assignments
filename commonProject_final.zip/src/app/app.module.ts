import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './user/dashboard/dashboard.component';
import { UserModule } from './user/user.module';
import { OrderRoutingModule } from './order/order-routing.module';
import { UserRoutingModule } from './user/user-routing.module';
import { OrderModule } from './order/order.module';
import { ProductModule } from './product/product.module';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UserModule,
    OrderModule,
    ProductModule   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
