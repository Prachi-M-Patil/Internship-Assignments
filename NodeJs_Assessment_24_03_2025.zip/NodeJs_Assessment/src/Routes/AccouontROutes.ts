import express from "express";
import { AccountController } from "../controllers/AccountController";
const router = express.Router();

router.post("/transfer", AccountController.transferMoney);
router.post("/create", AccountController.createAccount);


export default router;
