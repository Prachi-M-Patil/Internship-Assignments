import { Request, Response } from "express";
import { AccountService } from "../Services/AccountService";
export const AccountController = {
    transferMoney: async (req: Request, res: Response) => {
        const { accountAId, accountBId, amount } = req.body;

        try {
            await AccountService.transferMoney(accountAId, accountBId, amount);
            res.status(200).json({ message: "Funds transferred successfully!" });
        } catch (error: any) {
            res.status(400).json({ error: error.message });
        }
    },

    createAccount: async(req: Request, res: Response)=>{
        const {name, email, balance} =  req.body;

        try{
            await AccountService.createAccount(name, email, balance);
            res.status(200).json({message: "account created successfully"});
        }
        catch(error: any){
            res.status(400).json({error: error.message});
        }
    }
};
