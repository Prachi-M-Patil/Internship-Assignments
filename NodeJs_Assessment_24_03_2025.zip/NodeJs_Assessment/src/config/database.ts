import "reflect-metadata";
import { DataSource } from "typeorm";
import dotenv from "dotenv";
import { Account } from "../Models/Account";

dotenv.config();

export const AppDataSource = new DataSource({
    type: "mssql",
    port: 1982,
    username: process.env.DB_USER || "j2",
    password: process.env.DB_PASSWORD || "123456",
    host: process.env.DB_HOST || "dev.c5owyuw64shd.ap-south-1.rds.amazonaws.com",
    database: process.env.DB_NAME || "JIBE_MAIN_TRAINING",
    entities: [Account],
    synchronize: true, 
    logging: false,
    options: {
        trustServerCertificate: true,
    },
});
