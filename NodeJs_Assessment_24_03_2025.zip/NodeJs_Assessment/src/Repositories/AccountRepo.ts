import { AppDataSource } from "../config/database";
import { Account } from "../Models/Account";

export const AccountRepository = AppDataSource.getRepository(Account);
