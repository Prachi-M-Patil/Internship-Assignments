import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("accounts_Table") // Table name
export class Account {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    email: string;

    @Column({ type: "decimal"})
    balance: number;
}
