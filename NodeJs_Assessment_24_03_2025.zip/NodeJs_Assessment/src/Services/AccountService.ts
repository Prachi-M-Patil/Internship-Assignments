import { getConnection } from "typeorm";
import { Account } from "../Models/Account";
import { AccountRepository } from "../Repositories/AccountRepo";
import { AppDataSource } from "../config/database";

export class AccountService {
    static async createAccount(name: string, email: string, balance: number): Promise<Account> {
        
                if (!name || !email) {
                    throw new Error("Name and email are required.");
                }
        
                if (balance < 0) {
                    throw new Error("Initial balance cannot be negative.");
                }
        
                const existingAccount = await AccountRepository.findOneBy({ email });
                if (existingAccount) {
                    throw new Error("An account with this email already exists.");
                }
        
                const newAccount = new Account();
                newAccount.name = name;
                newAccount.email = email;
                newAccount.balance = balance;
        
                const savedAcc = await AccountRepository.save(newAccount);
                console.log(`Account created successfully with ID: ${savedAcc.id}`);
        
                return savedAcc;
        }
        


        static async transferMoney(accountAId: number, accountBId: number, amount: number): Promise<void> {
            if (amount <= 0) {
                throw new Error("Invalid transfer amount.");
            }
        
            try {
                await AppDataSource.transaction(async (transactionalEntityManager) => {


                    const accountA = await transactionalEntityManager
                        .createQueryBuilder()
                        .select("account")
                        .from(Account, "account")
                        .where("account.id = :id", { id: accountAId })
                        .getOne();
        
                    if (!accountA) {
                        throw new Error(`Account with accountId ${accountAId} not found.`);
                    }
        
                    if (accountA.balance < amount) {
                        throw new Error("Insufficient balance.");
                    }
        
                    console.log("account A fetched");





                    const accountB = await transactionalEntityManager
                        .createQueryBuilder()
                        .select("account")
                        .from(Account, "account")
                        .where("account.id = :id", { id: accountBId })
                        .getOne();
        
                    if (!accountB) {
                        throw new Error(`Account with accountId ${accountBId} not found.`);
                    }

                    console.log("account B fetched");

                    //update Account A
                    await transactionalEntityManager
                        .createQueryBuilder()
                        .update(Account)
                        .set({ balance: accountA.balance - amount })
                        .where("id = :id", { id: accountAId })
                        .execute();
                    console.log("account A updated");

                    throw new Error("Simulated error to trigger rollback!");

                    await transactionalEntityManager
                        .createQueryBuilder()
                        .update(Account)
                        .set({ balance: accountB.balance + amount })
                        .where("id = :id", { id: accountBId })
                        .execute();
                        console.log("account B updated");

        
                    console.log(`Transaction successful! Transferred $${amount} from Account ${accountAId} to Account ${accountBId}`);
                });
            } catch (error) {
                console.error("Transaction failed and was rolled back:", error.message);
                throw error; 
            }
        }
        
        }
        


// import { Account } from "../Models/Account";
// import { AccountRepository } from "../Repositories/AccountRepo";

// export class AccountService {
//     static async createAccount(name: string, email: string, balance: number): Promise<Account> {
        
//         if (!name || !email) {
//             throw new Error("Name and email are required.");
//         }

//         if (balance < 0) {
//             throw new Error("Initial balance cannot be negative.");
//         }

//         const existingAccount = await AccountRepository.findOneBy({ email });
//         if (existingAccount) {
//             throw new Error("An account with this email already exists.");
//         }

//         const newAccount = new Account();
//         newAccount.name = name;
//         newAccount.email = email;
//         newAccount.balance = balance;

//         const savedAcc = await AccountRepository.save(newAccount);
//         console.log(`Account created successfully with ID: ${savedAcc.id}`);

//         return savedAcc;
//     }

//     static async transferMoney(accountAId: number, accountBId: number, amount: number): Promise<void> {
//         if (amount <= 0) {
//             throw new Error("Invalid transfer amount.");
//         }

//         const accountA = await AccountRepository.findOneBy({ id: accountAId });
//         if (!accountA) {
//             throw new Error(`Account with accountId ${accountAId} not found.`);
//         }
//         if (accountA.balance < amount) {
//             throw new Error("Insufficient Balance.");
//         }

//         const accountB = await AccountRepository.findOneBy({ id: accountBId });
//         if (!accountB) {
//             throw new Error(`Account with accountId ${accountBId} not found.`);
//         }

//         try {
//             //Acc A balance = acc A - transfered amt; 

//             accountA.balance -= amount;
//             await AccountRepository.save(accountA);

//             //Acc b = balance + amt transfered

//             accountB.balance += amount;
//             await AccountRepository.save(accountB);

//             console.log(
//                 `Transaction successful! Transferred $${amount} from Account ${accountAId} to Account ${accountBId}`
//             );
//         } catch (error) {
//             console.error("Transaction failed:", error.message);
//             throw error;
//         }
//     }
// }

