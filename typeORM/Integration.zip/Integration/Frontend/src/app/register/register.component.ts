import { Component } from '@angular/core';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user ={
    username: '',
    password: '',
    email: ''
  };
  
  message: string | undefined;
  constructor(private registerService: RegisterService){

  }

  onSubmit(): void {
    this.registerService.registerUser(this.user).subscribe(
      (response) => {
        this.message = response.message;
      },
      (error) => {
        this.message = 'Failed to register user';
        console.error('Registration error:', error);
      }
    );
  }

}
