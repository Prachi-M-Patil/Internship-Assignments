import { Component } from '@angular/core';
import { LoginService } from '../login.service';


@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  credentials = {
    email: '',
    password: ''
  };

  message: string | undefined;

  constructor(private loginService: LoginService) {}

  onSubmit(): void {
    this.loginService.loginUser(this.credentials).subscribe(
      (response) => {
        this.message = response.message;
        console.log('Login successful:', response);
      },
      (error) => {
        this.message = 'Failed to log in. Check your email or password.';
        console.error('Login error:', error);
      }
    );
  }
}
