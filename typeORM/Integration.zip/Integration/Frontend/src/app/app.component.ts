import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent  {
  title = 'Frontend';
  message!: string;

  // constructor(private helloservice: HelloService){
// }
  // ngOnInit(): void {
  //   this.helloservice.getMessage().subscribe((message)=> {
  //     this.message = message;

  //   });
  // }
}
