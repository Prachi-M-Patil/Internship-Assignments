import "reflect-metadata";
import { DataSource } from "typeorm";
import dotenv from "dotenv";
import { User } from "../Models/User";


dotenv.config();

export const AppDataSource = new DataSource({
    type: "mssql",  
    port: 1982 , 
    username: "j2", 
    password: "123456", 
    host: "dev.c5owyuw64shd.ap-south-1.rds.amazonaws.com",
    database: "JIBE_MAIN_TRAINING", 
    entities:[User],
    // logging: true, 
    synchronize: false, 
    options: {
        trustServerCertificate: true,
    },
});
