import 'reflect-metadata';
import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import { AppDataSource } from './config/database';
import { User } from './Models/User';
import bcrypt from 'bcrypt'; // To hash and compare passwords
import jwt from 'jsonwebtoken';

const app = express();
const port = 3000;
const secret_key = 'this is my new secret key';

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Register a new user endpoint
app.post('/api/register', (req: Request, res: Response): void => {
    const { username, password, email } = req.body;

    // Access the User repository
    const userRepository = AppDataSource.getRepository(User);

    // Check if the user already exists
    userRepository.findOneBy({ email }).then((existingUser) => {
        if (existingUser) {
            res.status(400).json({ message: 'User already exists' });
        } else {
            // Hash the password before saving
            bcrypt.hash(password, 10).then((hashedPassword) => {
                const newUser = userRepository.create({ username, password: hashedPassword, email });
                userRepository.save(newUser)
                    .then(() => {
                        res.status(201).json({ message: 'User registered successfully' });
                    })
                    .catch((error) => {
                        console.error('Error while saving user:', error);
                        res.status(500).json({ error: 'Internal Server Error' });
                    });
            }).catch((error) => {
                console.error('Error while hashing password:', error);
                res.status(500).json({ error: 'Internal Server Error' });
            });
        }
    }).catch((error) => {
        console.error('Error while checking for existing user:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    });
});




app.post('/api/login', (req: Request, res: Response): void => {
        const { email, password } = req.body;
    
        // Access the User repository
        const userRepository = AppDataSource.getRepository(User);
    
        // Check if the user already exists
        userRepository.findOneBy({ email }).then((existingUser) => {
            if (!existingUser) {
                res.status(400).json({ message: 'User is not registered' });
            } else {
                // Compare the password with the stored hashed password
                bcrypt.compare(password, existingUser.password).then((isMatch) => {
                    if (!isMatch) {
                        res.status(401).json({ message: 'Invalid email or password' });
                    } else {
                        // Generate a JWT token
                        const token = jwt.sign(
                            { id: existingUser.id, email: existingUser.email },
                            'secret_key', // Replace with an environment variable in production
                            { expiresIn: '1h' }
                        );
    
                        res.status(200).json({
                            message: 'Login successful',
                            token,
                        });
                    }
                }).catch((error) => {
                    console.error('Error while comparing passwords:', error);
                    res.status(500).json({ error: 'Internal Server Error' });
                });
            }
        }).catch((error) => {
            console.error('Error while checking for existing user:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        });
              
});
    
AppDataSource.initialize()
    .then(() => {
        console.log('Data Source has been initialized!');
    })
    .catch((err) => {
        console.error('Error during Data Source initialization:', err);
});
    

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});



// import cors from 'cors';
// import express from "express";
// import { Request, Response } from 'express';

// const app = express();

// app.use(cors());
// app.use(express.json());

// app.get('/', (req: Request, res: Response)=>{
//     // res.send("Hello World");
//     res.status(201).json("Hello World" );
// })

// app.listen(3000,()=> console.log("Server running on port 3000"));
