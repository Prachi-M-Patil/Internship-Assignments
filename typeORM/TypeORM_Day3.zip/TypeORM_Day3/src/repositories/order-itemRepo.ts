import { AppDataSource } from "../config/database";
import { OrderItem } from "../models/order-item";


export const orderItemRepository = AppDataSource.getRepository(OrderItem);
