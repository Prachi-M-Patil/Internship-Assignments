import { Profile } from "../models/profile";
import { User } from "../models/user";
import { profileRepository } from "../repositories/profileRepo";
import { UserRepository } from "../repositories/userRepo";

export class UserService{
    async createUser(username: string, bio: string  ){
        const profile = new Profile();
        profile.bio = bio;
        const savedProfile = await profileRepository.save(profile);

        const user = new User();
        user.username = username;
        user.profile = savedProfile;

        return UserRepository.save(user);

    }

    async getUserById(userId: number): Promise<User | null> {
            return UserRepository.findOne({ where: { id: userId }, relations: ["profile", "orders"] });
    }

    async getAllUsers(): Promise<User[]> {
            return UserRepository.find({ relations: ["profile", "orders"] });
    }

}











// export class UserService {
//     async createUser(name: string, email: string, address: string, phone: string): Promise<User> {
//         const profile = new Profile();
//         profile.address = address;
//         profile.phone = phone;
//         const savedProfile = await profileRepository.save(profile);

//         const user = new User();
//         user.name = name;
//         user.email = email;
//         user.profile = savedProfile;

//         return userRepository.save(user);
//     }

//     async getUserById(userId: number): Promise<User | null> {
//         return userRepository.findOne({ where: { id: userId }, relations: ["profile", "orders"] });
//     }

//     async getAllUsers(): Promise<User[]> {
//         return userRepository.find({ relations: ["profile", "orders"] });
//     }
// }