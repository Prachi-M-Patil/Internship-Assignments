import { Profile } from "../models/profile";
import { profileRepository } from "../repositories/profileRepo";


export class ProfileService {
    async updateProfile(userId: number, address: string, phone: string): Promise<Profile | null> {
        const profile = await profileRepository.findOne({ where: { id: userId } });
        if (!profile) return null;

        profile.bio = address;
        return profileRepository.save(profile);
        
    }
}