import "reflect-metadata";
import { DataSource } from "typeorm";
import dotenv from "dotenv";
import { User } from "../models/user";
import { Profile } from "../models/profile";
import { Product } from "../models/product";
import { Order } from "../models/order";
import { OrderItem } from "../models/order-item";



dotenv.config();

export const AppDataSource = new DataSource({
    type: "mssql",  
    port: Number(process.env.DB_PORT) , 
    username: process.env.DB_USER, 
    password: process.env.DB_PASS, 
    host: process.env.DB_HOST,
    database: process.env.DB_NAME, 
    entities:[],
    logging: true, 
    synchronize: true, 
    options: {
        trustServerCertificate: true,
    },
});
