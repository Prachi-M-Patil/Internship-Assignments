import { Column, Entity, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { Profile } from "./profile";
import { Order } from "./order";


@Entity({name: "tblUSER_Relationships1"})
export class User{
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ default: "", name: "username" })
    username: string;

    @OneToOne(()=> Profile, {cascade: true})
    @JoinColumn()
    profile: Profile; 

    @OneToMany(() => Order , (order) => order.user)
    orders: Order[];
    
}
