

import { Column, Entity, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./user";
import { Product } from "./product";
import { OrderItem } from "./order-item";

@Entity()
export class Order{
    @PrimaryGeneratedColumn()
    id: number;

    @Column({default: "default_price"})
    price: number

    @ManyToOne(() => User, (user)=> user.orders)
    user: User[];

    @OneToMany(()=> OrderItem, (orderItem)=> orderItem.order, {cascade: true})
    orderItems: OrderItem[];


}