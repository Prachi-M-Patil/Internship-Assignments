import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: "My_Profile"})
export class Profile{
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    bio: string;

}