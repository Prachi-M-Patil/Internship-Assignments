import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Order } from "./order";
import { OrderItem } from "./order-item";

@Entity()
export class Product{
       @PrimaryGeneratedColumn()
        id: number;
    
        @Column({ default: "", name: "ProdName" })
        username: string;

        @OneToMany(()=> OrderItem , (orderItem)=> orderItem.prduct)
        orderItems: OrderItem[];
    

}