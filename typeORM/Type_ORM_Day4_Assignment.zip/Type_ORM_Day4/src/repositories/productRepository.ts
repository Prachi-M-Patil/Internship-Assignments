import { AppDataSource } from "../Config/database";
import { Product } from "../models/product";

export const productRepository =  AppDataSource.getRepository(Product);