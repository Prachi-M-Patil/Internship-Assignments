import { Request, Response } from "express";
import { addProduct, getFilteredProducts } from "../services/ProductService";

// export const getFilteredProductsHandler = async (req:Request, res: Response) => {
//     try{
//         const filters = req.body;
//     const result = await getFilteredProducts(filters);
//     res.status(200).json(result);
//     } catch(err){
//         res.status(500).json({err: (err as Error).message});
//     }
    
// }

export const getProductsController = async (req: Request, res: Response) => {
    const filters = {
      category: req.query.category,
      minPrice: req.query.minPrice,
      maxPrice: req.query.maxPrice,
      brand: req.query.brand,
      rating: req.query.rating,
      sortBy: req.query.sortBy
    };
  
    try {
      const products = await getFilteredProducts(filters);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Error fetching filtered products" });
    }
  };

export const addProductController = async (req: Request, res: Response) => {
    const productData = req.body;
  
    try {
      const product = await addProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  };
  
  