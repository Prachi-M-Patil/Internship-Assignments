import { Router } from "express";
import { addProductController, getProductsController } from "../controllers/productController";
// import { getFilteredProductsHandler } from "../controllers/productController";

export const productRouter = Router();

productRouter.get("/products", getProductsController);                             
productRouter.post("/products", addProductController );                             