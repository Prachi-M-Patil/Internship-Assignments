import { Column, Entity, PrimaryGeneratedColumn, Timestamp } from "typeorm";

@Entity('My_Product_table')
export class Product{
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    category:"Electronics"| "Clothing" | "Home Applications";
    
    @Column({type: "decimal"})
    price: number;
    
    @Column()
    brand: string;
    
    @Column()
    ratings: number;
    
    @Column()
    sales: number;
    
    @Column({ type: 'datetime', default: () => "CURRENT_TIMESTAMP" })
    date: Date;

}