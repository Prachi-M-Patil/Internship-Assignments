import { Product } from "../models/product";
import { productRepository } from "../repositories/productRepository";
import { SelectQueryBuilder } from "typeorm";

export const getFilteredProducts = async (filters: any) => {
  let query: SelectQueryBuilder<Product> = productRepository
    .createQueryBuilder("product");

  if (filters.category) {
    query.andWhere("product.category = :category", { category: filters.category });
  }
//product.category: Refers to the category column in the product table.
//= :category: The :category is a placeholder for a parameter that will be replaced with an actual value.
  if (filters.minPrice && filters.maxPrice) {
    query.andWhere("product.price BETWEEN :minPrice AND :maxPrice", {
      minPrice: filters.minPrice,
      maxPrice: filters.maxPrice,
    });
  }

  if (filters.brand) {
    query.andWhere("product.brand = :brand", { brand: filters.brand });
  }

  if (filters.rating) {
    query.andWhere("product.rating >= :rating", { rating: filters.rating });
  }

  // Sorting
  const sortOptions: { [key: string]: string } = {
    priceLowToHigh: "product.price ASC",
    priceHighToLow: "product.price DESC",
    newest: "product.createdAt DESC",
    bestSellers: "product.sales DESC",
  };

  if (filters.sortBy && sortOptions[filters.sortBy]) {
    query.orderBy(sortOptions[filters.sortBy]);
  }

//   // Pagination
//   const page = parseInt(filters.page) || 1;
//   const pageSize = parseInt(filters.pageSize) || 10;
//   query.skip((page - 1) * pageSize).take(pageSize);

  return await query.getMany();

  

};

export const addProduct = async (productData: Partial<Product>) => {
  const product = productRepository.create(productData);
  await productRepository.save(product);
  return product;
};


