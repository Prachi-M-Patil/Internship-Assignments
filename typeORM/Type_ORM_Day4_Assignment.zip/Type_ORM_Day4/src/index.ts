import express from 'express';
import { AppDataSource } from './Config/database';
import { productRouter } from './Routes/productRoute';

const app = express();
const port = process.env.Port || 4200;

app.use(express.json());
app.use("/product", productRouter);


AppDataSource.initialize().then(()=>{
    console.log("connected successfully");

    app.listen(port, () => {
        console.log(`Server is running on port ${port}`);
    });

})
.catch((error)=>{
    console.log("error occured", error)
})





