import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { Profile } from "./profile";

@Entity({name: "tblUSER_Prachi"})
export class User{
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    username: string;

    @Column()
    email: string;

    @OneToOne(() => Profile, (profile) => profile.user, { cascade: true })
    @JoinColumn() 
    profile: Profile;//Added { cascade: true } to the @OneToOne relationship in the User entity. 
    // This ensures that when a User is created or updated, the Profile entity will also be
    //  persisted automatically.

}