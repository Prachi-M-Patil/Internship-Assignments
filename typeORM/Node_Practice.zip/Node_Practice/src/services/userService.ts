import { User } from "../models/user";
import { profileRepository } from "../repositories/profileRepo";
import { userRepository } from "../repositories/userRepo";

export class UserService {
    async createUser(username: string, email: string, bio: string): Promise<User> {
        // Create and save the Profile
        const profile = profileRepository.create({ bio });
        await profileRepository.save(profile);

        // Create and save the User
        const user = userRepository.create({ username, email, profile });
        return userRepository.save(user);
    }
}
