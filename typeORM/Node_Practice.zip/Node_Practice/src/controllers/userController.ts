import { UserService } from "../services/userService"
import {Request, Response} from 'express';

const userService = new UserService

export class UserController{
    createUser = async (req: Request, res: Response) => {
        const { username, email, bio } = req.body;
    
        // Validate input
        if (!username || !email || !bio) {
            return res.status(400).json({ error: "Invalid input: Username, email, and bio are required." });
        }
    
        try {
            const user = await userService.createUser(username, email, bio);
            res.status(201).json(user);
        } catch (error) {
            console.error("Error creating user:", error);
            res.status(500).json({ error: "An error occurred while creating the user." });
        }
    };
    
}