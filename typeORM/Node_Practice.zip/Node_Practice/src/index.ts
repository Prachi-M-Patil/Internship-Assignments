import { AppDataSource } from "./config/database";
import express from 'express';
import userRoutes from "./routes/userRoutes";

const app = express();
const port = process.env.Port || 3000;

app.use(express.json());
app.use("/user", userRoutes);

AppDataSource.initialize().then(()=>{
    console.log("connected successfully")
})
.catch((error)=>{
    console.log("error occured")
})

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});



