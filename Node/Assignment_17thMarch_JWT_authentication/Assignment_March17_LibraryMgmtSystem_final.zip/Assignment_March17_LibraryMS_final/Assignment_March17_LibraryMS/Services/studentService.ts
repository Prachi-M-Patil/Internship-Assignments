import { StudentRepository } from '../Repositories/studentRepo';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
import { BorrowedBooks } from '../models/borrowedBooks';
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const SECRET_KEY = "9bb70c026a02e1ab3118db84bec6d413fa636c3e7751c59f795bb40db3826c06";
class StudentService {
    private studentRepository = new StudentRepository();

    async searchBook(title:string): Promise<Book> {
        return await this.studentRepository.searchBook(title);
    }

    async ViewBook(): Promise<Book[] | null> {
        return await this.studentRepository.viewBook();
    }

    async borrowBook(bookId:number, title:string, userId:number){
        await this.studentRepository.borrowBook(bookId, title, userId);
    }

    async returnBook(bookId:number,userId:number){
        await this.studentRepository.returnBook(bookId,userId);
    }
}

export { StudentService };
