import { AdminRepository } from '../Repositories/adminRepo';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const SECRET_KEY = "9bb70c026a02e1ab3118db84bec6d413fa636c3e7751c59f795bb40db3826c06";
class AdminService {
    private adminRepository = new AdminRepository();

    async addBook(book: Book): Promise<Book> {
        return await this.adminRepository.addBook(book);
    }

    async deleteBook(id: number): Promise<void> {
        await this.adminRepository.deleteBook(id);
    }

    async updateBook(id:number, availableCopies:number): Promise<void> {
        await this.adminRepository.updateBook(id, availableCopies);
    }
}

export { AdminService };
