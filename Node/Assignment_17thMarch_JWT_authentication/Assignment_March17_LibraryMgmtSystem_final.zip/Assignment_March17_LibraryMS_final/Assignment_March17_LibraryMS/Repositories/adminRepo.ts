import { poolPromise } from '../config/database';
import { Book } from '../models/book.model';

class AdminRepository {
    // Get all books
    async getAllBooks(): Promise<Book[]> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");

            const result = await pool.request().query("SELECT * FROM LibBookTbl");

            return result.recordset.map((row: { id: number; title: string; author: string; isbn: string; availableCopies: number; totalCopies: number }) =>
                new Book(row.id, row.title, row.author, row.isbn, row.availableCopies, row.totalCopies)
            );
        } catch (error) {
            console.error("Error fetching books:", error);
            throw new Error("Failed to retrieve books");
        }
    }

    // Add a new book
    async addBook(book: Book): Promise<Book> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");

            const result = await pool.request()
                .input('title', book.title)
                .input('author', book.author)
                .input('isbn', book.isbn)
                .input('availableCopies', book.availableCopies)
                .input('totalCopies', book.totalCopies) // Ensure totalCopies is included
                .query(`INSERT INTO LibBookTbl (title, author, isbn, availableCopies, totalCopies) 
                        VALUES (@title, @author, @isbn, @availableCopies, @totalCopies);
                        SELECT SCOPE_IDENTITY() AS id;`);

            book.id = result.recordset[0].id;
            return book;
        } catch (error) {
            console.error("Error adding book:", error);
            throw new Error("Error adding book");
        }
    }

    // Update book available copies
    async updateBook(id: number, availableCopies: number): Promise<void> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");

            await pool.request()
                .input('id', id)
                .input('availableCopies', availableCopies)
                .query("UPDATE LibBookTbl SET availableCopies = @availableCopies WHERE bookId = @id");
        } catch (error) {
            console.error("Error updating book:", error);
            throw new Error("Failed to update book");
        }
    }

    // Delete a book
    async deleteBook(id: number): Promise<boolean> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");

            const result = await pool.request()
                .input('id', id)
                .query("DELETE FROM LibBookTbl WHERE bookId = @id");

            return result.rowsAffected[0] > 0;
        } catch (error) {
            console.error("Error deleting book:", error);
            return false;
        }
    }
}

export { AdminRepository };
