import { poolPromise } from '../config/database';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
import sql from 'mssql';
import { BorrowedBooks } from '../models/borrowedBooks';

class StudentRepository {

    //search book by name
    async searchBook(title:string):Promise<Book> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('title', sql.VarChar, title)
            .query("SELECT * FROM LibBookTbl WHERE title = @title");
        
        const bookRecord = result.recordset[0];
        const book: Book = {
            id: bookRecord.id,
            title: bookRecord.title,
            author: bookRecord.author,
            isbn: bookRecord.isbn,
            availableCopies: bookRecord.availableCopies,
            totalCopies: bookRecord.totalCopies
        };
        return book;
    }

    //View all books
    async viewBook(): Promise<Book[] | null> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");
    
            const result = await pool.request()
                .query("SELECT * FROM LibBookTbl");
    
            return result.recordset;
        } catch (error) {
            console.error("Error viewing books:", error);
            return null;
        }
    }

    //borrow Book
    async borrowBook(bookId:number, title:string, userId:number){
        const pool=await poolPromise;
        if(!pool) throw new Error("DB Connection Failed!");

        const bookResult=await sql.query`select availableCopies from LibBookTbl where bookId=@bookId`;
        const book=bookResult.recordset[0];
        
        if(!book || book.availableCopies<=0){
            throw new Error("Book is not available right now");
        }

        //update book table and reduce number of available copies
        await sql.query`update LibBookTbl set availableCopies=availableCopies-1 where bookId=@BookId `;

        //insert record into borrowed book table
        await sql.query`insert into BorrowedBooksTbl(userId, bookId, title, BorrowedDate, returnDate) values(@userId, @title, GETDATE(), 0)`;
        
        return {message: "Book Borrowed Successfully..."};
    }

    //Return Book
    async returnBook(bookId:number, userId:number){
        const pool=await poolPromise;
        if(!pool) throw new Error("DB Connection Failed!");

        const bookResult=await sql.query`select userId, bookId from BorrowedBooksTbl where bookId=@bookId AND userId=@userId`;
        const book=bookResult.recordset[0];
        
        if(!book){
            throw new Error("There is no record with in borrowed books with same credentials...");
        }

        //update book table and reduce number of available copies
        await sql.query`update LibBookTbl set availableCopies=availableCopies+1 where bookId=@BookId `;

        //insert record into borrowed book table
        await sql.query`delete from BorrowedBookTbl where bookId=@bookId AND userId=@userId`;
        
        return {message: "Book returned Successfully..."};
    }

}

export { StudentRepository};