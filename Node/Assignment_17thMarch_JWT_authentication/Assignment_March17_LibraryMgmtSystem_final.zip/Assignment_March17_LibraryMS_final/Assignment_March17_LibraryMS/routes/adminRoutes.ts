import { Router } from 'express';
import { AdminController } from '../controllers/AdminController';
import  {authenticateUser,roleBasedAuth}  from '../middleware/authMiddleware';
const router = Router();
const adminController = new AdminController();

router.put('/books/:id/update', (req, res) => adminController.updateBook(req, res));
router.post('/books',authenticateUser,roleBasedAuth(["Admin","Manager"]) ,  adminController.addBook);
router.put('/books/:id/delete', (req, res) => adminController.deleteBook(req, res));

export default router;