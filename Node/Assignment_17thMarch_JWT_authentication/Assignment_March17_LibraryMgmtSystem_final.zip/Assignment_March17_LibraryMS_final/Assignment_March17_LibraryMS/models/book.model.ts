class Book {
    constructor(
        public id: number,
        public title: string,
        public author: string,
        public isbn: string,
        public availableCopies:number,
        public totalCopies : number
    ) {}
}

export { Book };