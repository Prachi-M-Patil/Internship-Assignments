class BorrowedBooks{
    constructor(
        public id:number,
        public userId:number,
        public bookId:number,
        public title:string,
        public borrowedDate:Date,
        public returnDate:Date
    ){}
}

export {BorrowedBooks}