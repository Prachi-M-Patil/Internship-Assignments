import { Request, Response } from 'express';
import { StudentService } from '../Services/studentService';
import { Book } from '../models/book.model';
import { BorrowedBooks } from '../models/borrowedBooks';

const studentService = new StudentService();

class StudentController {
    async viewBook(req: Request, res: Response): Promise<void> {
        try {
            const books = await studentService.ViewBook();
            res.status(200).json(books);
        } catch (error) {
            res.status(500).json({ message: 'Error viewing books', error });
        }
    }

    async searchBook(req: Request, res: Response): Promise<void> {
        try {
            const { title } = req.body;
            const book = await studentService.searchBook(title);
            res.status(200).json(book);
        } catch (error) {
            res.status(500).json({ message: 'Error searching book', error });
        }
    }
    
    async borrowBook(req: Request, res: Response): Promise<void> {
        try {
            const { bookId, title, userId } = req.body;
            const result = await studentService.borrowBook(bookId, title, userId);
            res.status(200).json(result);
        } catch (error) {
            res.status(500).json({ message: 'Error borrowing book', error });
        }
    }

    async returnBook(req: Request, res: Response): Promise<void> {
        try {
            const { bookId, userId } = req.body;
            const result = await studentService.returnBook(bookId, userId);
            res.status(200).json(result);
        } catch (error) {
            res.status(500).json({ message: 'Error returning book', error });
        }
    }
}

export { StudentController};
