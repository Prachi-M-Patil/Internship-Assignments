class Leave {
    constructor(
        public id: number,
        public employeeId: number,
        public startDate: Date,
        public endDate: Date,
        public leaveType: string, // Sick/Vacation
        public status: string,    // Pending/Approved/Rejected
        public reason: string
    ) {}
}

export { Leave };
