class Employee {
    constructor(
        public id: number,
        public name: string,
        public email: string,
        public role: string // Employee/Manager/Admin
    ) {}
}

export { Employee };
