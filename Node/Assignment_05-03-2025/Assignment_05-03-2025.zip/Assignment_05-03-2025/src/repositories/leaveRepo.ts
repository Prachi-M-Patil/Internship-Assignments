import { poolPromise } from '../config/database';
import { Leave } from '../models/leaveModel';

class LeaveRepository {
    async getAllLeaves(): Promise<Leave[]> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");
        
        const result = await pool.request().query("SELECT * FROM tblLeave");
        return result.recordset.map(row => new Leave(row.id, row.employee_id, row.start_date, row.end_date, row.leave_type, row.status, row.reason));
    }

    async getLeavesByEmployeeId(employeeId: number): Promise<Leave[]> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('employeeId', employeeId)
            .query("SELECT * FROM tblLeave WHERE employee_id = @employeeId");
        return result.recordset.map(row => new Leave(row.id, row.employee_id, row.start_date, row.end_date, row.leave_type, row.status, row.reason));
    }

    async createLeave(leave: Leave): Promise<Leave> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('employeeId', leave.employeeId)
            .input('startDate', leave.startDate)
            .input('endDate', leave.endDate)
            .input('leaveType', leave.leaveType)
            .input('status', leave.status)
            .input('reason', leave.reason)
            .query("INSERT INTO tblLeave (employee_id, start_date, end_date, leave_type, status, reason) VALUES (@employeeId, @startDate, @endDate, @leaveType, @status, @reason); SELECT SCOPE_IDENTITY() AS id;");
        leave.id = result.recordset[0].id;
        return leave;
    }

    async updateLeaveStatus(id: number, status: string): Promise<void> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        await pool.request()
            .input('id', id)
            .input('status', status)
            .query("UPDATE tblLeave SET status = @status WHERE id = @id");
    }

    async deleteLeave(id: number): Promise<boolean> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('id', id)
            .query("DELETE FROM tblLeave WHERE id = @id");
        return result.rowsAffected[0] > 0;
    }

    async getPendingLeaves(): Promise<Leave[]> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .query("SELECT * FROM tblLeave WHERE status = 'Pending'");
        return result.recordset.map(row => new Leave(row.id, row.employee_id, row.start_date, row.end_date, row.leave_type, row.status, row.reason));
    }
}

export { LeaveRepository };
