import sql, { ConnectionPool } from "mssql";
import 'dotenv/config'
const config: sql.config = {
  user: process.env.DB_USER || "j2",
  password: process.env.DB_PASSWORD || "123456",
  server: process.env.DB_SERVER || "dev.c5owyuw64shd.ap-south-1.rds.amazonaws.com",
  port: 1982,
  database: process.env.DB_NAME || "JIBE_Main_Trainings",
  options: {
    encrypt: false, 
    trustServerCertificate: true 
  }
};

async function connectToDB(): Promise<ConnectionPool> {
  try {
    const pool = await sql.connect(config); // Connect to the database
    console.log("Connected to SQL Server");
    return pool; // Return the connection pool
  } catch (err) {
    console.error("DB connection failed", err);
    throw err; // Re-throw the error for better error handling
  }
}

// Export the connection pool as a promise
const poolPromise: Promise<ConnectionPool> = connectToDB();

export { poolPromise };
