export interface Task{
    id: number,
    name: string,
    status: 'completed' | 'in progress' | 'pending',
    description: string
}