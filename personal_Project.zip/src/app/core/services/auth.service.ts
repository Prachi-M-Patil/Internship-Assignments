import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private authState = new BehaviorSubject<boolean>(this.isLoggedIn());
  authstate$ = this.authState.asObservable();

  private roleSubject = new BehaviorSubject<string| null>(this.getRole());
  role$ = this.roleSubject.asObservable();

  login(role: string){
    localStorage.setItem('user_role', role);
    this.authState.next(true);
    this.roleSubject.next(role);
  }

  logout(){
    localStorage.clear();
    this.authState.next(false);
    this.roleSubject.next(null);
  }
  constructor() { }

  isLoggedIn(): boolean{
    return localStorage.getItem('user_role')!= null;

  }

  getRole(): string| null{
    return localStorage.getItem('user_role');

  }

  isAdmin(): boolean{
    return this.getRole() === 'admin';
  }
}
