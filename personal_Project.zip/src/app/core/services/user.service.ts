import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  private users: User[]= JSON.parse(localStorage.getItem('users') || '[]');
    private userSubject = new BehaviorSubject<User[]>(this.users);
    users$ = this.userSubject.asObservable();
  

    saveUser(){
      localStorage.setItem('users', JSON.stringify(this.users));
      this.userSubject.next([...this.users]);
  
    }
  
    addUser(user: User){
      this.users.push(user);
      this.saveUser();
    }
  
    updateUser(updatedUser: User){
      this.users.map(user => user.id === updatedUser.id ? updatedUser:user );
      this.saveUser();
    }
    deleteUser(id: number){
       this.users =this.users.filter(user => user.id !== id);
       this.saveUser();
  
    }
  
    getUserById(id: number): User| undefined{
      return this.users.find(user => user.id === id);
  
    }
}
