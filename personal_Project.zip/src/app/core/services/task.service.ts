import { Injectable } from '@angular/core';
import { Task } from '../models/task.model';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasks: Task[]= JSON.parse(localStorage.getItem('tasks') || '[]');
  private taskSubject = new BehaviorSubject<Task[]>(this.tasks);
  tasks$ = this.taskSubject.asObservable();

  constructor(private authservice:AuthService) { 
    // const savedTasks = localStorage.getItem('tasks');
    // if(savedTasks){
    //   this.tasks
    // }
  }

  saveTask(){
    localStorage.setItem('tasks', JSON.stringify(this.tasks));
    this.taskSubject.next([...this.tasks]);

  }

  addTask(task: Task){
    
      this.tasks.push(task);
      this.saveTask();
    
   
   
  }

  updateTask(updatedTask: Task){
  
    this.tasks.map(task => task.id === updatedTask.id ? updatedTask:task );
    this.saveTask();
    
   
  }
  deleteTask(id: number){
     this.tasks =this.tasks.filter(task => task.id !== id);
     this.saveTask();

  }

  updateStatus(taskId: number, status:'completed' | 'in progress' | 'pending') {
    const task = this.tasks.find(task => task.id === taskId);
    if (task) {
      task.status = status; // Assuming Task model has a status property
      this.saveTask();
    }
  }

  getTaskById(id: number): Task| undefined{
    return this.tasks.find(task => task.id === id);

  }
}
