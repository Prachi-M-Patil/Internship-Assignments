import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoaderComponent } from './components/loader/loader.component';
import { AuthModule } from '../auth/auth.module';



@NgModule({
  declarations: [
    NavbarComponent,
    LoaderComponent
  ],
  imports: [
    CommonModule,
    AuthModule
  ],
  exports:[
    NavbarComponent,
    LoaderComponent
  ]
})
export class SharedModule { }
