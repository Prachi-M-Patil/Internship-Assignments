import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username= '';
  password= '';
  
  constructor(private authservice: AuthService, private router: Router){

  }

  login(){
    if(this.username === 'admin' && this.password === 'admin'){
      this.authservice.login('admin');
      this.router.navigate(['/tasks']);
    }
    else{
      this.authservice.login('user');
      this.router.navigate(['/tasks']);
    } 
  }

}
