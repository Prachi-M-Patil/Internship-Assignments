import { Component } from '@angular/core';
import { Task } from '../../../core/models/task.model';

@Component({
  selector: 'app-task-detail',
  standalone: false,
  templateUrl: './task-detail.component.html',
  styleUrl: './task-detail.component.css'
})
export class TaskDetailComponent {
  task: Task={id:0,name: '',status: 'pending' ,description: ''};

}
