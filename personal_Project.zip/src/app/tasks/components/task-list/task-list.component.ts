import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../../core/services/task.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Task } from '../../../core/models/task.model'; // Adjust the import path as needed
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-task-list',
  standalone: false,
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css'] // Corrected to styleUrls
})
export class TaskListComponent implements OnInit {
  tasks!:Task[]; // Explicitly define the type
  constructor(private taskService: TaskService, private router: Router, public authService: AuthService) {}

  ngOnInit(): void {
    this.taskService.tasks$.subscribe(tasks => this.tasks = tasks)
  }

 updateStatus(taskId: number, status: 'completed' | 'in progress' | 'pending') {
    // Assuming updateStatus method exists in TaskService
    this.taskService.updateStatus(taskId, status);
  }

  deleteTask(id: number): void {
    this.taskService.deleteTask(id);
  
 }

}
