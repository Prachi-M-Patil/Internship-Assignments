import { Component } from '@angular/core';
import { Task } from '../../../core/models/task.model';
import { TaskService } from '../../../core/services/task.service';

@Component({
  selector: 'app-task-form',
  standalone: false,
  templateUrl: './task-form.component.html',
  styleUrl: './task-form.component.css'
})
export class TaskFormComponent {

  task: Task={id:0,name: '',status: 'pending' ,description: ''};

  constructor(private taskService: TaskService){

  }
  addTask() {
    this.task.id = Date.now();
    this.taskService.addTask(this.task);
    alert('task added successfully!!');
  }

  updateTask(updatedTask: Task) {
    this.taskService.updateTask(updatedTask);
  }

  updateStatus(taskId: number, status: 'completed' | 'in progress' | 'pending') {
    // Assuming updateStatus method exists in TaskService
    this.taskService.updateStatus(taskId, status);
  }
}
  
    

  
 
 
