import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './user/login/login.component';
import { RegisterComponent } from './user/register/register.component';

const routes: Routes = [
  {path:'user', loadChildren:() =>
     import ('./user/user.module').then(m => m.UserModule)},
  {path:'admin', loadChildren:() =>
    import ('./admin/admin.module').then(m => m.AdminModule)},
 {
  path:'order',
  loadChildren:()=>import("./order/order.module").then((m)=>m.OrderModule)
 },
 
  {path:'register', component:RegisterComponent},
  {path:'product', loadChildren:()=>import('./product/product.module').then(m=> m.ProductModule)}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }
