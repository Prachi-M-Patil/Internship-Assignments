import { Component } from '@angular/core';
import { Product, ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  standalone: false,
  
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  title:string= "my Website";
  today= new Date();
  products: Product[] = [];

  constructor(private productService: ProductService) {
    this.products = this.productService.getProducts();
  }

  addProduct(){
    const newProduct: Product = { id: 0, name: 'New Product', description: 'New Description', price: 0 };
    this.productService.addProduct(newProduct);
    this.products = this.productService.getProducts(); // Refresh the product list
   
  }

  deleteProduct(id: number): void {
    this.productService.deleteProduct(id);
    this.products = this.productService.getProducts(); 
  }

}
