import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipeDemo',
  standalone: false
})
export class PipeDemoPipe implements PipeTransform {
//join is used to reverse the string
  transform(value: string):string {
    return value.split('').reverse().join('');
  }

}
