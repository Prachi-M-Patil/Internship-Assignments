import { Component } from '@angular/core';
import { Order, OrderService } from '../order.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-order-details',
  standalone: false,
  
  templateUrl: './order-details.component.html',
  styleUrl: './order-details.component.css'
})
export class OrderDetailsComponent {
  order: Order | undefined;

  constructor(
    private route: ActivatedRoute,
    private orderService: OrderService
  ) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.order = this.orderService.getOrderById(id);
  }

}
