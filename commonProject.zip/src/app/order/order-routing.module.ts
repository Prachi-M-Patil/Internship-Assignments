import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { CustomerGuard } from '../auth/customer.guard';


const routes: Routes = [
    {path: 'orders', component: OrderListComponent, canActivate:[CustomerGuard]},
    {path:'order-orders/:id', component:OrderDetailsComponent,canActivate:[CustomerGuard]}
 

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderRoutingModule { }
