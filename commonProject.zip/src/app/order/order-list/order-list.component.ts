import { Component } from '@angular/core';
import { Order, OrderService } from '../order.service';

@Component({
  selector: 'app-order-list',
  standalone: false,
  
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css'
})
export class OrderListComponent {
  orders: Order[] = [];

  constructor(private orderService: OrderService) {
    this.orders = this.orderService.getOrders();
  }
  addOrder(){
    
  }

  deleteOrder(id: number): void {
    this.orderService.deleteOrder(id);
    this.orders = this.orderService.getOrders(); // Refresh the order list
  }
}