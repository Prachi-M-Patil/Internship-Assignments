import { Injectable } from '@angular/core';

export interface Order {
  id: number;
  name: string;
  description: string;
  total: number;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private orders: Order[] = [
    { id: 1, name: 'Order 1', description: 'Description 1', total: 100 },
    { id: 2, name: 'Order 2', description: 'Description 2', total: 200 }
  ];

  constructor() { }

  getOrders(): Order[] {
    return this.orders;
  }

  getOrderById(id: number): Order | undefined {
    return this.orders.find(o => o.id === id);
  }

  addOrder(order: Order): Order {
    order.id = this.orders.length + 1;
    this.orders.push(order);
    return order;
  }

  deleteOrder(id: number): void {
    this.orders = this.orders.filter(o => o.id !== id);
  }

}
