import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateFn, GuardResult, MaybeAsync, Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';
import { Role } from '../role';
Injectable({
  providedIn: 'root'
})

export class ManagerGuard implements CanActivate {
  constructor(private authService:AuthService){}
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      return this.authService.isUserAuthenticated(Role.Manager)
    }
  // constructor(private authService: AuthService, private router: Router){}
  // canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean {
  //   const val = localStorage.getItem('isLogged');
  //   if(val !== 'true'){
  //     this.router.navigate(['/']);
  //     return false;
  //   }

  //   const role = localStorage.getItem('role');

  //   if(role !== 'customer'){
  //     return true;
  //   }

  //   this.router.navigate(['/']);
  //   return false;



  // }
  
}